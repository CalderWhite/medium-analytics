import Donut from "./Donut.js";

export default Donut;