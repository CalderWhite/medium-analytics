const AnalyticsEngine = require("./AnalyticsEngine.js")
const engine = new AnalyticsEngine("./medium-analytics-firebase.json");
/*
engine.getSnapshots('1:yeod91jnKdfwfnaAFg6lGQ7NWcXQN35ROJXRxFtOntyP8O8nHo/D+p6v5cC7OqE7',"2017",(data) => {
    console.log(data)
})
*/
engine.addSnapshot(
    'calderwhite',
    '7b4b89f35552',
    '1:yeod91jnKdfwfnaAFg6lGQ7NWcXQN35ROJXRxFtOntyP8O8nHo/D+p6v5cC7OqE7'
)
/*
engine.getDataSnapshot(
    'calderwhite',
    '7b4b89f35552',
    '1:yeod91jnKdfwfnaAFg6lGQ7NWcXQN35ROJXRxFtOntyP8O8nHo/D+p6v5cC7OqE7',
    (err,data) =>{
        if(err != null){
            console.log(err);
        } else{
            console.log(JSON.stringify(data));
        }
    }
);
*/