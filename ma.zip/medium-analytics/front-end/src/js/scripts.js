// 3rd party utils module
import Immutable from 'immutable';
// REACT
import ReactDOM from 'react-dom';
import React, { Component } from 'react';
// Draggable module
import Reorder, { reorderImmutable } from "react-reorder";

// import our components
import Donut from "./components";

// import third party graphinh modules
import {AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip} from "recharts";

import tinygradient from "tinygradient";

// import our own firebase library
import firebaseUtils from "./firebaseConnector";

// import our data util library
import {Utils, analyticsFrontendEngine} from "./analyticsFrontendEngine";
// shorten this mouthful a little bit
const dataUtils = analyticsFrontendEngine;

// import our stylesheets we need
import "../css/index.scss"
// get the DOM element that our app is based on
const app = document.getElementById("app");
// test data
// TODO: Remove this for production
const testSessionId = "1:yeod91jnKdfwfnaAFg6lGQ7NWcXQN35ROJXRxFtOntyP8O8nHo/D+p6v5cC7OqE7";

class StackedAreaChart extends Component{
  constructor(props){
    super(props)
  }
	render () {
  	return (
    	<AreaChart width={600} height={400} data={[
      {name: 'Page A', dip: 4000, ass: 2400, amt: 2400},
      {name: 'Page B', dip: 3000, ass: 1398, amt: 2210},
      {name: 'Page C', dip: 2000, ass: 9800, amt: 2290},
      {name: 'Page D', dip: 2780, ass: 3908, amt: 2000},
      {name: 'Page E', dip: 1890, ass: 4800, amt: 2181},
      {name: 'Page F', dip: 2390, ass: 3800, amt: 2500},
      {name: 'Page G', dip: 3490, ass: 4300, amt: 2100},
      ]}
            margin={{top: 10, right: 30, left: 0, bottom: 0}}>
        <XAxis dataKey="name"/>
        <YAxis/>
        <CartesianGrid strokeDasharray="3 3"/>
        <Tooltip/>
        {
          this.props.metaData.map(({dataKey,color})=>{
            return <Area type='monotone' dataKey={dataKey} stackId={1} stroke={color} fill={color} key={dataKey} />
          })
        }
      </AreaChart>
    );
  }
}

export class Grid extends Component {
  constructor () {
    super();
    this.state = {
      list: Immutable.List([
        "referrals",
        "referralViews"
      ]),
      data:null,
      referrals:"Loading...",
      referralViews:"Loading..."
    };
    firebaseUtils.getData(testSessionId,(data)=>{
      // set the referrals donut
      firebaseUtils.getLatestSnapshot(data,(snapshot)=>{
        // process the data for the donut
        let donutData = dataUtils.cleanseReferralList(dataUtils.formatToDonutData(snapshot.referrers,'name','views'),1)
        // generate colors for our graphs in the medium-analytics green theme
        let colors = tinygradient("#334C1A","#66ff99").rgb(donutData.length).map(({_r,_g,_b})=>{
          return Utils.rgbToHex(Math.floor(_r),Math.floor(_g),Math.floor(_b));
        });
        this.setState({
          referrals:(<Donut 
                    data={donutData} 
                    colors={colors}
                    donutKey="referrals"/>),
        });
      });
      firebaseUtils.getLatestMonth(data);
    });
  }

  onReorder (event, previousIndex, nextIndex) {
    const list = reorderImmutable(this.state.list, previousIndex, nextIndex);

    this.setState({
      list: list
    });
  }

  render () {
    return (
      <div>
        <Reorder
          reorderId="myList3"
          component="ul"
          className="my-list"
          placeholderClassName="drop-projection"
          draggedClassName='dragged'
          onReorder={this.onReorder.bind(this)}
        >
          {
            this.state.list.map((name) => {
            var classNames = ['list-item list-item-3 card'];
            var content;
            switch(name){
              case "referrals":
              classNames.push('referrals');
              break;
              default:
              content = name;
              break;
            }
            return (
              <div className={classNames.join(' ')} key={name}>
                <div className="card-header">{name}</div>
                <div className="card-block">
                {this.state[name]}
                </div>
              </div>
            )
            }).toArray()
          }
        </Reorder>
      </div>
    );
  }
}

ReactDOM.render(
  <Grid/>,
  app
);