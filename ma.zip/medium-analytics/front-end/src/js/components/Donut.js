import React from "react";

const $ = require("jquery");

// since morris uses outdated jquery, set a window-scope variable to point to our modern jquery.
window.jQuery = $;
// raphael is a dependancy of morris
window.Raphael = require("raphael");
/* global Morris */
// the code that is imported assigned the module to a global variable called "Morris"
// so what we do is require it to include it in our code and refer to it as Moriss since it will ultimately be in the scope
// Pretty ugly, I know. However, there isn't much I could do without messing with Morris' source code.
require("morris.js");

export default class Donut extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      angle:450,
      angleIncrement: -6,
      increase:true,
      circle:null
    };
    this.componentDidMount = this.componentDidMount.bind(this);
    this.updateLoader = this.updateLoader.bind(this);
    this.loadInGraph = this.loadInGraph.bind(this);
  }
  componentDidMount(){
    let total = 0;
    for(let i=0;i<this.props.data.length;i++){
      total+=this.props.data[i].value;
    };
    // since morris.js is not designed for react, it appends and element to the DOM.
    // because of this, we also must go through the DOM. I know, pretty ugly.
    new Morris.Donut({
      // ID of the element in which to draw the chart.
      element: 'donut-' + this.props.donutKey,
      // Chart data records -- each entry in this array corresponds to a point on
      // the chart.
      data: this.props.data,
      formatter : (item) =>{
        // *100 so we round to 2 decimal plNaces
        let percent = Math.round(100*100*item/total)/100;
        return percent.toString() + "% of views";
      },
      colors:this.props.colors
    });
    this.loadInGraph();
  }
  loadInGraph(){
    var parent = $('#donut-' + this.props.donutKey);
    var svg = parent[0].children[0];
    if(window["donut-" + this.props.donutKey] != false){
      // add it in the white circle for the load in effect
      let loader = document.createElement("circle");
      svg.appendChild(loader);
      loader.style.marginLeft="100px";
      loader.outerHTML = `<circle cx="250" cy="150" r="75" fill="none" stroke="#ffffff" stroke-width="150" stroke-dasharray="0,20000" />`;
      // hide the text to fade in later.
      $('#donut-' + this.props.donutKey + ' > svg > text').css('opacity','0');
      parent[0].style.display = "block";
      // now get the width to figure out how much left margin should be applied (whether it be negative or positive)
      svg.style.marginLeft = ( -($(svg).width() - parent.width()) / 2).toString() + "px";
      // run the loading animation
      this.updateLoader();
      window["donut-" + this.props.donutKey] = false;
    } else{
      parent[0].style.display = "block";
      // now get the width to figure out how much left margin should be applied (whether it be negative or positive)
      svg.style.marginLeft = ( -($(svg).width() - parent.width()) / 2).toString() + "px";
    }
  }
  updateLoader(){
    const interval = 30;
    let newAngle = this.state.angle;
    let newIncrement;
    if(this.state.angleIncrement < -50){
      this.setState({
        increase:false
      });
    }
    if(this.state.increase){
      newIncrement = this.state.angleIncrement*1.17;
    } else{
      newIncrement = Math.min(this.state.angleIncrement/1.5,-2);
    }
    this.setState({
      angle:newAngle + newIncrement,
      angleIncrement:newIncrement
    });
    var svg = $('#donut-' + this.props.donutKey + ' > svg')[0];
    svg.children[svg.children.length-1].setAttribute("stroke-dasharray", this.state.angle + ", 20000");
    if (newAngle > 0 && newAngle + newIncrement > 0) {
      setTimeout(this.updateLoader,interval);
    } else{
      svg.removeChild(svg.children[svg.children.length-1]);
      $('#donut-' + this.props.donutKey + ' > svg > text').fadeTo(800,1);
    }
  }
  render(){
    return (
      <div id={"donut-" + this.props.donutKey} style={{height: 300,display:"none"}}>
      </div>
    );
  }
}