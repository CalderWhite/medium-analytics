export class Utils{
    static componentToHex(c) {
        var hex = c.toString(16);
        return hex.length == 1 ? "0" + hex : hex;
    }
    
    static rgbToHex(r, g, b) {
        return "#" + Utils.componentToHex(r) + Utils.componentToHex(g) + Utils.componentToHex(b);
    }

}
export class analyticsFrontendEngine{
    /**
     * Format a list of objects to viable morris.js donut data.
     * @param key The name of the refferer
     * @param value The key that represents the portion of the donut that the given referrer takes up.
     */
    static formatToDonutData(referrals,key,value){
        for(let i=0;i<referrals.length;i++){
            referrals[i] = {
                label:referrals[i][key],
                value:referrals[i][value]
            }
        }
        return referrals;
    }
    /**
     * Removes excluded labels along with other utilities based on the parameters given.
     * @param minimumPortion Default:-1 The minimum percentage of `.value` required to be an individual portion of the donut. Those will be clumped into an element called "other".
     */
    static cleanseReferralList(referrals,minimumPortion){
        if(minimumPortion == undefined){
            // exclude none if minimumPortion is not set
            minimumPortion = -1;
        }
        referrals.push({label:'Other',value:0})
        // find total of all values
        let total = 0;
        referrals.map(({value})=>{total+=value});
        // create a pointer to shorten names
        let excludes = analyticsFrontendEngine.excludeReferrals;
        // subtract 2 so we don't loop over the 'Other' element
        for(let i=referrals.length-2;i>=0;i--){
            // if .label is in the excludes list then remove it from the array
            for(let j=0;j<excludes.length;j++){
                if(referrals[i].label.search(excludes[j]) > -1){
                    referrals.splice(i,1)
                }
            }
            // check that the value is above the minimum requirement
            if(referrals[i].value / total < minimumPortion/100){
                // the last element is Other, so add the value to it
                referrals[referrals.length-1].value+=referrals[i].value
                // remove the item
                referrals.splice(i,1)
            }
        }
        // since the last element will always be the other element we appended at the beginning, we can check it by accesing
        // the last element of the array. Remove it if its value is zero
        if(referrals[referrals.length-1].value == 0){
            referrals.splice(referrals.length-1,1)
        }
        // place the `other` item in sorted order, since this list is sorted
        let other = referrals.pop(referrals.length-1)
        let i = referrals.length-1;
        if (i<0){
            referrals.splice(i+1,0,other)
            return referrals;
        }
        while(i >=0 && other.value > referrals[i].value){
            i--
        }
        referrals.splice(i+1,0,other)
        return referrals;
    }
}
analyticsFrontendEngine.excludeReferrals = ['RSS readers']